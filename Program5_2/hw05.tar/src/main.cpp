// Name: Dang Tran
// ID:S856F975
// File: main.cpp
// Assignment:4

#include "test_interface.hpp"

int main()
{
	runTests();

	return 0;
}
